package com.example.swarnimgupta.gpslocation;

import android.location.Location;
import android.location.LocationListener;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements LocationListener{

    TextView tv,tv2;
    Button button1,button2;
    ProgressBar pb;
    GPSTracker gpsTracker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //locationButton=(Button)findViewById(R.id.button);
        tv=(TextView)findViewById(R.id.latlong);
        tv2=(TextView)findViewById(R.id.address);
        button1=(Button)findViewById(R.id.button);
        pb=(ProgressBar)findViewById(R.id.progressBar);
        tv.setVisibility(View.GONE);
        tv2.setVisibility(View.GONE);
        button1.setVisibility(View.INVISIBLE);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pb.setVisibility(View.VISIBLE);
                getLocationNow();
            }
        });
        getLocationNow();
//        locationButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                gpsTracker = new GPSTracker(MainActivity.this);
//                if (gpsTracker.canGetLocation()) {
//                    double latitude = gpsTracker.getLatitude();
//                    double longitude = gpsTracker.getLongitude();
//                    LocationAddress locationAddress = new LocationAddress();
//                    locationAddress.getAddressFromLocation(latitude, longitude,
//                            getApplicationContext(), new GeocoderHandler());
//                    //Toast.makeText(getApplicationContext(),"Your Location Latitude is: "+latitude+" and Longitude is: "+longitude,Toast.LENGTH_LONG).show();
//                }else{
//                    gpsTracker.showSettingsAlert();
//                }
//            }
//        });
    }

    public void getLocationNow(){
        gpsTracker = new GPSTracker(MainActivity.this);
        if (gpsTracker.canGetLocation()) {
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();
            LocationAddress locationAddress = new LocationAddress();
            locationAddress.getAddressFromLocation(latitude, longitude,
                   MainActivity.this, new GeocoderHandler());
            //Toast.makeText(getApplicationContext(),"Your Location Latitude is: "+latitude+" and Longitude is: "+longitude,Toast.LENGTH_LONG).show();
        }else{
            gpsTracker.showSettingsAlert();
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    private class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData();
                    locationAddress = bundle.getString("address");
                    break;
                default:
                    locationAddress = null;
            }
            tv.setVisibility(View.VISIBLE);
            tv2.setVisibility(View.VISIBLE);
            pb.setVisibility(View.GONE);
            tv.setText(locationAddress);
            button1.setVisibility(View.VISIBLE);
        }
    }

}




